/*
Author: Lizhe Zhang
Class: ECE4122 Last Date Modified: Dec 6
Description:
Final ECE_OBJ_Loader header file
 */

#pragma once

#include "shaders.h"
#include "vertexBufferObject.h"
#include "texture.h"

class CMaterial
{
public:
	int iTexture;
};

class ECE_OBJ_Loader
{
public:
	bool loadFile(const std::string &filename);

	static void FinalizeVBO();
	static void BindModelsVAO();

	void renderMeshes();
	ECE_OBJ_Loader();
private:
	bool bLoaded;
	static CVertexBufferObject vboModelData;
	static UINT uiVAO;
	static vector<CTexture> tTextures;
	vector<int> iMeshStartIndices;
	vector<int> iMeshSizes;
	vector<int> iMaterialIndices;
	int iNumMaterials;
};
